#include "utils.h"

void SolveTask2() {
    // TODO
}