#pragma once
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

void SolveTask1();
void SolveTask2();
void SolveTask3();
