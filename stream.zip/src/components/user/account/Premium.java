package components.user.account;

public interface Premium {
    int PRICE = 10;
    int NR_FREE_MOVIES = 15;
    String TYPE = "premium";
}
