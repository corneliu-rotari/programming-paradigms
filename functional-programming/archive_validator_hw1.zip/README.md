# Archive validator for homeworks

## Usage

`python3 archive_validator.py <archive_name>`

## Yaml config

In order to validate the homework, you should have a `ref.yaml` file that specifies the format of the archive.
